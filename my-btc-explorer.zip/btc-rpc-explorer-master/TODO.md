* moment -> luxon  :/
* value-validation in /changeSetting (like is currently done for userTzOffset)

* 24hr comparisons for exchange rate/gold rate?
* /mempool-summary: more granular fee rate bar chart; add line graph on top of bar chart for cumulative blocks
* incoming tx page (live)
* electron: https://gist.github.com/maximilian-lindsey/a446a7ee87838a62099d

* use flex utilities for "summary rows"?