"use strict";

const btc = require("./coins/btc.js");

module.exports = {
	"BTC": btc,

	"coins":["BTC"]
};